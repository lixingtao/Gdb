From page 95.  This is a buggy version.
