A fixed version of bintree.
