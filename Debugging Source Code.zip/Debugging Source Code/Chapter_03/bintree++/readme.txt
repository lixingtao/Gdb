From page 109.
