From page 106.
