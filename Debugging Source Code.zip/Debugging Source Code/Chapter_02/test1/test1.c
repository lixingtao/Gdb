int main( void )
{
	int i;
	i = 3;

	return 0;
}
