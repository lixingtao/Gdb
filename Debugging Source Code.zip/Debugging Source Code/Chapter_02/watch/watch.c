#include <stdio.h>
int i = 0;

int main( void )
{
	i = 3;
	printf("i is %d.\n", i);

	i = 5;
	printf("i is %d.\n", i);

	return 0;
}
