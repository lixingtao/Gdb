From pp.164-166.

Makefile depends on which implementation of MPI is used,
but no special libraries or includes are needed beyond that.

