From pp.172-175.

Makefile depends on which implementation of OpenMP is used,
but no special libraries or includes are needed beyond that.

