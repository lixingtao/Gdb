int q[200];


int main( void )
{
	for( int i = 0; i < 2000; i++ )
		q[i] = i;

	return 0;
}
