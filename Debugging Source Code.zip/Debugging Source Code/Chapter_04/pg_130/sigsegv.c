#include <stdio.h>

int main(void)
{
	char *c = 0;
	printf("%s\n", *c);

	return 0;
}
