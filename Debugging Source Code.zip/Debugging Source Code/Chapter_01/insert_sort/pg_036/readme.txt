After we insert this code:

	// one more case: new_y > all existing y elements
	y[num_y] = new_y;

just after line 44.
