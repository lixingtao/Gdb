#include <stdio.h>



int main( void )
{
	int i;

	scanf("%d", &i);

	return 0;
}
